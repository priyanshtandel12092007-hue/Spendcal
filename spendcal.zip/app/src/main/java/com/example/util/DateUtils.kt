package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateUtils {
    private val isoDateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val monthYearFormat = SimpleDateFormat("yyyy-MM", Locale.US)
    private val displayMonthYearFormat = SimpleDateFormat("MMMM yyyy", Locale.US)
    private val displayDateFormat = SimpleDateFormat("EEE, MMM d, yyyy", Locale.US)
    private val shortDateFormat = SimpleDateFormat("MMM d", Locale.US)

    @Synchronized
    fun getTodayIso(): String {
        return isoDateFormat.format(Date())
    }

    @Synchronized
    fun getCurrentMonthYear(): String {
        return monthYearFormat.format(Date())
    }

    @Synchronized
    fun formatToDisplayMonth(year: Int, month: Int): String {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month - 1)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        return displayMonthYearFormat.format(cal.time)
    }

    @Synchronized
    fun formatIsoToDisplay(isoDate: String): String {
        return try {
            val date = isoDateFormat.parse(isoDate) ?: Date()
            displayDateFormat.format(date)
        } catch (e: Exception) {
            isoDate
        }
    }

    @Synchronized
    fun formatIsoToShort(isoDate: String): String {
        return try {
            val date = isoDateFormat.parse(isoDate) ?: Date()
            shortDateFormat.format(date)
        } catch (e: Exception) {
            isoDate
        }
    }

    @Synchronized
    fun toIsoDate(year: Int, month: Int, day: Int): String {
        return String.format(Locale.US, "%04d-%02d-%02d", year, month, day)
    }

    @Synchronized
    fun getDaysInMonth(year: Int, month: Int): Int {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month - 1)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        return cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    }

    @Synchronized
    fun getFirstDayOfWeekInMonth(year: Int, month: Int): Int {
        // 1 = Sunday, 2 = Monday, ... 7 = Saturday
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month - 1)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        return cal.get(Calendar.DAY_OF_WEEK)
    }

    @Synchronized
    fun parseIsoParts(isoDate: String): Triple<Int, Int, Int> {
        val parts = isoDate.split("-")
        return if (parts.size == 3) {
            Triple(
                parts[0].toIntOrNull() ?: 2026,
                parts[1].toIntOrNull() ?: 10,
                parts[2].toIntOrNull() ?: 1
            )
        } else {
            Triple(2026, 10, 1)
        }
    }
}
