package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AccountEntity
import com.example.data.model.Categories
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.TransferBlue
import com.example.util.DateUtils
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddEditTransactionSheet(
    onDismiss: () -> Unit,
    accounts: List<AccountEntity>,
    currencySymbol: String,
    initialDate: String,
    editingTx: TransactionEntity? = null,
    onSave: (
        id: Long,
        type: String,
        amount: Double,
        title: String,
        category: String,
        date: String,
        accountId: Long,
        toAccountId: Long?,
        note: String,
        fee: Double
    ) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var selectedType by remember {
        mutableStateOf(
            editingTx?.type ?: TransactionType.EXPENSE.name
        )
    }

    var amountText by remember {
        mutableStateOf(if (editingTx != null) String.format(Locale.US, "%.2f", editingTx.amount) else "")
    }

    var title by remember { mutableStateOf(editingTx?.title ?: "") }
    var selectedCategory by remember {
        mutableStateOf(editingTx?.category ?: Categories.expenseCategories.first())
    }
    var selectedDate by remember { mutableStateOf(editingTx?.date ?: initialDate) }
    var note by remember { mutableStateOf(editingTx?.note ?: "") }
    var feeText by remember {
        mutableStateOf(if (editingTx?.transferFee != null && editingTx.transferFee > 0) editingTx.transferFee.toString() else "")
    }

    val defaultAccount = accounts.firstOrNull { it.isDefault } ?: accounts.firstOrNull()
    var selectedAccountId by remember {
        mutableLongStateOf(editingTx?.accountId ?: defaultAccount?.id ?: 1L)
    }

    val defaultToAccount = accounts.firstOrNull { it.id != selectedAccountId } ?: accounts.lastOrNull()
    var selectedToAccountId by remember {
        mutableLongStateOf(editingTx?.toAccountId ?: defaultToAccount?.id ?: 2L)
    }

    var showCalculator by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
                .imePadding()
                .navigationBarsPadding()
                .testTag("add_transaction_sheet")
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (editingTx != null) "Edit Transaction" else "Record Transaction",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss, modifier = Modifier.testTag("dismiss_add_sheet")) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Type Selector Tabs (Expense, Income, Transfer Mode)
            val types = listOf(TransactionType.EXPENSE.name, TransactionType.INCOME.name, TransactionType.TRANSFER.name)
            TabRow(
                selectedTabIndex = types.indexOf(selectedType).coerceAtLeast(0),
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.clip(RoundedCornerShape(14.dp))
            ) {
                types.forEach { type ->
                    val isSelected = selectedType == type
                    val tabColor = when (type) {
                        TransactionType.EXPENSE.name -> ExpenseRed
                        TransactionType.INCOME.name -> IncomeGreen
                        else -> TransferBlue
                    }

                    Tab(
                        selected = isSelected,
                        onClick = {
                            selectedType = type
                            if (type == TransactionType.EXPENSE.name && selectedCategory !in Categories.expenseCategories) {
                                selectedCategory = Categories.expenseCategories.first()
                            } else if (type == TransactionType.INCOME.name && selectedCategory !in Categories.incomeCategories) {
                                selectedCategory = Categories.incomeCategories.first()
                            } else if (type == TransactionType.TRANSFER.name) {
                                selectedCategory = "Transfer"
                            }
                        },
                        text = {
                            Text(
                                text = when (type) {
                                    TransactionType.EXPENSE.name -> "Expense"
                                    TransactionType.INCOME.name -> "Income"
                                    else -> "⇄ Transfer"
                                },
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) tabColor else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        modifier = Modifier.testTag("type_tab_$type")
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Amount Input Row with Built-In Calculator Shortcut!
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it
                        errorText = null
                    },
                    label = { Text("Amount ($currencySymbol)") },
                    leadingIcon = {
                        Text(
                            text = currencySymbol,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(start = 12.dp)
                        )
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("amount_input_field"),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Built-in Calculator Shortcut Button
                Surface(
                    onClick = { showCalculator = true },
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .testTag("launch_calculator_from_input"),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    tonalElevation = 2.dp
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Calculate,
                            contentDescription = "Quick Calculator",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Title Input
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text(if (selectedType == TransactionType.TRANSFER.name) "Transfer Description" else "Title / Merchant") },
                placeholder = {
                    Text(
                        when (selectedType) {
                            TransactionType.EXPENSE.name -> "e.g. Starbucks, Groceries"
                            TransactionType.INCOME.name -> "e.g. Monthly Salary, Freelance project"
                            else -> "e.g. ATM withdrawal, moving to savings"
                        }
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("title_input_field"),
                shape = RoundedCornerShape(14.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Account Selectors
            if (selectedType == TransactionType.TRANSFER.name) {
                // Transfer Mode: Source & Destination
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "Transfer Mode Details",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = TransferBlue
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        // From Account
                        AccountDropdown(
                            label = "From Account",
                            selectedAccountId = selectedAccountId,
                            accounts = accounts,
                            onAccountSelected = { selectedAccountId = it },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // To Account
                        AccountDropdown(
                            label = "To Destination Account",
                            selectedAccountId = selectedToAccountId,
                            accounts = accounts.filter { it.id != selectedAccountId },
                            onAccountSelected = { selectedToAccountId = it },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Transfer Fee
                        OutlinedTextField(
                            value = feeText,
                            onValueChange = { feeText = it },
                            label = { Text("Transfer Fee (Optional)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )
                    }
                }
            } else {
                // Expense or Income: Single Account
                AccountDropdown(
                    label = if (selectedType == TransactionType.INCOME.name) "Deposit To Account" else "Pay From Account",
                    selectedAccountId = selectedAccountId,
                    accounts = accounts,
                    onAccountSelected = { selectedAccountId = it },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Category Chips
                Text(
                    text = "Category",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))

                val availableCategories = if (selectedType == TransactionType.EXPENSE.name) {
                    Categories.expenseCategories
                } else {
                    Categories.incomeCategories
                }

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    availableCategories.forEach { cat ->
                        val isCatSelected = selectedCategory == cat
                        FilterChip(
                            selected = isCatSelected,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 12.sp) },
                            shape = RoundedCornerShape(10.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            ),
                            modifier = Modifier.testTag("category_chip_$cat")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Date Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = selectedDate,
                    onValueChange = { selectedDate = it },
                    label = { Text("Date (YYYY-MM-DD)") },
                    leadingIcon = {
                        Icon(Icons.Default.CalendarMonth, contentDescription = null)
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Optional Note
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("Notes (Optional)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                maxLines = 2
            )

            if (errorText != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = errorText ?: "",
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Save Action
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull()
                    if (amt == null || amt <= 0.0) {
                        errorText = "Please enter a valid amount greater than 0"
                        return@Button
                    }
                    if (selectedType == TransactionType.TRANSFER.name && selectedAccountId == selectedToAccountId) {
                        errorText = "Source and destination accounts must be different"
                        return@Button
                    }

                    val fee = feeText.toDoubleOrNull() ?: 0.0
                    onSave(
                        editingTx?.id ?: 0L,
                        selectedType,
                        amt,
                        title,
                        if (selectedType == TransactionType.TRANSFER.name) "Transfer" else selectedCategory,
                        selectedDate,
                        selectedAccountId,
                        if (selectedType == TransactionType.TRANSFER.name) selectedToAccountId else null,
                        note,
                        fee
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_transaction_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = when (selectedType) {
                        TransactionType.EXPENSE.name -> ExpenseRed
                        TransactionType.INCOME.name -> IncomeGreen
                        else -> TransferBlue
                    }
                )
            ) {
                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (editingTx != null) "Update Transaction" else "Save Transaction",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }

        // Quick Built-in Calculator Modal Sheet triggered from amount
        if (showCalculator) {
            BuiltInCalculatorSheet(
                onDismiss = { showCalculator = false },
                initialValue = amountText,
                onApplyValue = { calcResult ->
                    amountText = String.format(Locale.US, "%.2f", calcResult)
                    showCalculator = false
                }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountDropdown(
    label: String,
    selectedAccountId: Long,
    accounts: List<AccountEntity>,
    onAccountSelected: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    val selectedAccount = accounts.find { it.id == selectedAccountId } ?: accounts.firstOrNull()

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded },
        modifier = modifier
    ) {
        OutlinedTextField(
            value = selectedAccount?.name ?: "Select Account",
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .fillMaxWidth()
                .menuAnchor(),
            shape = RoundedCornerShape(14.dp)
        )

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            accounts.forEach { account ->
                DropdownMenuItem(
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(Color(android.graphics.Color.parseColor(account.colorHex)))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(account.name, fontWeight = FontWeight.Medium)
                        }
                    },
                    onClick = {
                        onAccountSelected(account.id)
                        expanded = false
                    }
                )
            }
        }
    }
}
