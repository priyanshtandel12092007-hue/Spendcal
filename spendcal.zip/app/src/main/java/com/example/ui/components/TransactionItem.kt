package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalMall
import androidx.compose.material.icons.filled.LocalPharmacy
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AccountEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.TransferBlue
import java.util.Locale

@Composable
fun TransactionItem(
    transaction: TransactionEntity,
    accounts: List<AccountEntity>,
    currencySymbol: String,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val fromAccount = accounts.find { it.id == transaction.accountId }
    val toAccount = if (transaction.toAccountId != null) accounts.find { it.id == transaction.toAccountId } else null

    val isExpense = transaction.type == TransactionType.EXPENSE.name
    val isIncome = transaction.type == TransactionType.INCOME.name
    val isTransfer = transaction.type == TransactionType.TRANSFER.name

    val categoryIcon = getCategoryIcon(transaction.category, transaction.type)
    val iconColor = when {
        isExpense -> ExpenseRed
        isIncome -> IncomeGreen
        else -> TransferBlue
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("transaction_item_${transaction.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Category Icon Badge
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(iconColor.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = categoryIcon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Details Column
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = transaction.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1
                )

                Spacer(modifier = Modifier.height(2.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (isTransfer) {
                        Text(
                            text = fromAccount?.name ?: "Account",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            modifier = Modifier.size(11.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = toAccount?.name ?: "Account",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TransferBlue
                        )
                    } else {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = fromAccount?.name ?: "Cash",
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = "• ${transaction.category}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (transaction.note.isNotBlank()) {
                    Text(
                        text = transaction.note,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                        maxLines = 1
                    )
                }
            }

            // Amount and Delete Action
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = when {
                        isExpense -> "-$currencySymbol${String.format(Locale.US, "%.2f", transaction.amount)}"
                        isIncome -> "+$currencySymbol${String.format(Locale.US, "%.2f", transaction.amount)}"
                        else -> "↔ $currencySymbol${String.format(Locale.US, "%.2f", transaction.amount)}"
                    },
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = iconColor
                )

                if (isTransfer && transaction.transferFee > 0) {
                    Text(
                        text = "Fee: $currencySymbol${String.format(Locale.US, "%.2f", transaction.transferFee)}",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .size(28.dp)
                        .testTag("delete_transaction_${transaction.id}")
                ) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Delete",
                        modifier = Modifier.size(15.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                }
            }
        }
    }
}

fun getCategoryIcon(category: String, type: String): ImageVector {
    if (type == TransactionType.TRANSFER.name) return Icons.Default.SwapHoriz
    if (type == TransactionType.INCOME.name) return Icons.Default.Payments

    return when {
        category.contains("Food", ignoreCase = true) || category.contains("Dining", ignoreCase = true) -> Icons.Default.Restaurant
        category.contains("Groceries", ignoreCase = true) -> Icons.Default.ShoppingBag
        category.contains("Transport", ignoreCase = true) || category.contains("Fuel", ignoreCase = true) -> Icons.Default.DirectionsCar
        category.contains("Bills", ignoreCase = true) || category.contains("Utilities", ignoreCase = true) -> Icons.Default.Receipt
        category.contains("Shopping", ignoreCase = true) -> Icons.Default.LocalMall
        category.contains("Entertainment", ignoreCase = true) -> Icons.Default.Movie
        category.contains("Health", ignoreCase = true) || category.contains("Medical", ignoreCase = true) -> Icons.Default.LocalPharmacy
        category.contains("Education", ignoreCase = true) -> Icons.Default.School
        category.contains("Travel", ignoreCase = true) -> Icons.Default.Flight
        category.contains("Home", ignoreCase = true) || category.contains("Rent", ignoreCase = true) -> Icons.Default.Home
        else -> Icons.Default.Payments
    }
}
