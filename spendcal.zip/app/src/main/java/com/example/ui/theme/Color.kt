package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Emerald Fintech Palette
val EmeraldPrimary = Color(0xFF006C4C)
val EmeraldOnPrimary = Color(0xFFFFFFFF)
val EmeraldPrimaryContainer = Color(0xFF8CF8C6)
val EmeraldOnPrimaryContainer = Color(0xFF002114)

val EmeraldPrimaryDark = Color(0xFF6FDBAB)
val EmeraldOnPrimaryDark = Color(0xFF003825)
val EmeraldPrimaryContainerDark = Color(0xFF005238)
val EmeraldOnPrimaryContainerDark = Color(0xFF8CF8C6)

val AmberSecondary = Color(0xFF825500)
val AmberOnSecondary = Color(0xFFFFFFFF)
val AmberSecondaryContainer = Color(0xFFFFDDB3)
val AmberOnSecondaryContainer = Color(0xFF291800)

val AmberSecondaryDark = Color(0xFFFFBA53)
val AmberOnSecondaryDark = Color(0xFF452B00)
val AmberSecondaryContainerDark = Color(0xFF623F00)
val AmberOnSecondaryContainerDark = Color(0xFFFFDDB3)

val CyanTertiary = Color(0xFF00677D)
val CyanTertiaryDark = Color(0xFF5DD5FC)

// Functional Financial Colors
val ExpenseRed = Color(0xFFE11D48)
val ExpenseRedLight = Color(0xFFFFE4E6)
val IncomeGreen = Color(0xFF059669)
val IncomeGreenLight = Color(0xFFD1FAE5)
val TransferBlue = Color(0xFF2563EB)
val TransferBlueLight = Color(0xFFDBEAFE)
val TargetWarning = Color(0xFFD97706)
val TargetWarningLight = Color(0xFFFEF3C7)
val TargetExceeded = Color(0xFFDC2626)

// Surface and Backgrounds
val SurfaceLight = Color(0xFFF8FAFC)
val CardLight = Color(0xFFFFFFFF)
val BorderLight = Color(0xFFE2E8F0)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)

val SurfaceDark = Color(0xFF0B131F)
val CardDark = Color(0xFF131D2D)
val BorderDark = Color(0xFF1E293B)
val TextPrimaryDark = Color(0xFFF1F5F9)
val TextSecondaryDark = Color(0xFF94A3B8)
