package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.TargetExceeded
import com.example.ui.theme.TargetWarning
import com.example.util.DateUtils
import java.util.Locale

@Composable
fun DailySpendingBarChart(
    year: Int,
    month: Int,
    dailyTotals: Map<Int, Double>,
    dailyTarget: Double,
    currencySymbol: String,
    modifier: Modifier = Modifier
) {
    val daysInMonth = DateUtils.getDaysInMonth(year, month)
    var selectedDay by remember { mutableStateOf<Int?>(null) }

    val maxDaily = (dailyTotals.values.maxOrNull() ?: 10.0).coerceAtLeast(dailyTarget * 1.2)
    val animatedProgress by animateFloatAsState(
        targetValue = 1f,
        animationSpec = tween(700),
        label = "chart_anim"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("daily_spending_chart_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Daily Expenses vs Target",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (selectedDay != null) {
                            "Day $selectedDay: $currencySymbol${String.format(Locale.US, "%.2f", dailyTotals[selectedDay] ?: 0.0)}"
                        } else {
                            "Tap any bar to inspect daily spend"
                        },
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp, 2.dp)
                            .background(MaterialTheme.colorScheme.primary)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Target ($currencySymbol${String.format(Locale.US, "%.0f", dailyTarget)})",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Canvas Bar Chart
            val targetLineColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
            val gridLineColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.15f)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .pointerInput(daysInMonth) {
                            detectTapGestures { offset ->
                                val barWidth = size.width / daysInMonth
                                val tappedIndex = (offset.x / barWidth).toInt() + 1
                                if (tappedIndex in 1..daysInMonth) {
                                    selectedDay = tappedIndex
                                }
                            }
                        }
                ) {
                    val w = size.width
                    val h = size.height
                    val barWidth = (w / daysInMonth) * 0.7f
                    val slotWidth = w / daysInMonth

                    // Draw Daily Target dashed line
                    val targetY = h - ((dailyTarget / maxDaily).toFloat() * h)
                    drawLine(
                        color = targetLineColor,
                        start = Offset(0f, targetY),
                        end = Offset(w, targetY),
                        strokeWidth = 2.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                    )

                    // Draw Bars
                    for (day in 1..daysInMonth) {
                        val amount = dailyTotals[day] ?: 0.0
                        val barHeight = ((amount / maxDaily).toFloat() * h * animatedProgress).coerceAtLeast(0f)
                        val x = (day - 1) * slotWidth + (slotWidth - barWidth) / 2
                        val y = h - barHeight

                        val barColor = when {
                            amount == 0.0 -> gridLineColor
                            amount > dailyTarget -> TargetExceeded
                            amount >= dailyTarget * 0.8 -> TargetWarning
                            else -> IncomeGreen
                        }

                        drawRoundRect(
                            color = if (selectedDay == day) barColor else barColor.copy(alpha = 0.85f),
                            topLeft = Offset(x, y),
                            size = Size(barWidth, barHeight.coerceAtLeast(4f)),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx(), 4.dp.toPx())
                        )
                    }
                }
            }

            // X-Axis Labels (Day 1, 5, 10, 15, 20, 25, End)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val labelDays = listOf(1, 5, 10, 15, 20, 25, daysInMonth)
                for (day in labelDays) {
                    Text(
                        text = "$day",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = if (selectedDay == day) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }
}

@Composable
fun MonthlyBudgetGaugeCard(
    totalMonthlyExpense: Double,
    monthlyBudget: Double,
    dailyAverage: Double,
    projectedMonthEnd: Double,
    currencySymbol: String,
    onEditBudget: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ratio = if (monthlyBudget > 0) (totalMonthlyExpense / monthlyBudget).toFloat() else 0f
    val displayRatio = ratio.coerceIn(0f, 1f)
    val animatedRatio by animateFloatAsState(targetValue = displayRatio, animationSpec = tween(800), label = "gauge_anim")

    val isOverBudget = monthlyBudget > 0 && totalMonthlyExpense > monthlyBudget
    val remaining = (monthlyBudget - totalMonthlyExpense).coerceAtLeast(0.0)

    val gaugeColor = when {
        isOverBudget -> TargetExceeded
        ratio >= 0.85f -> TargetWarning
        else -> IncomeGreen
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("monthly_budget_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Monthly Budget Overview",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Budget: $currencySymbol${String.format(Locale.US, "%.2f", monthlyBudget)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    onClick = onEditBudget,
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.testTag("edit_monthly_budget_chip")
                ) {
                    Text(
                        text = "Edit Budget",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Ring Gauge and Main Metrics
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Circular Progress Ring
                Box(
                    modifier = Modifier.size(100.dp),
                    contentAlignment = Alignment.Center
                ) {
                    val trackColor = MaterialTheme.colorScheme.surfaceVariant
                    Canvas(modifier = Modifier.size(100.dp)) {
                        val stroke = 10.dp.toPx()
                        drawArc(
                            color = trackColor,
                            startAngle = 135f,
                            sweepAngle = 270f,
                            useCenter = false,
                            style = Stroke(width = stroke, cap = StrokeCap.Round)
                        )
                        drawArc(
                            color = gaugeColor,
                            startAngle = 135f,
                            sweepAngle = 270f * animatedRatio,
                            useCenter = false,
                            style = Stroke(width = stroke, cap = StrokeCap.Round)
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${(ratio * 100).toInt()}%",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = gaugeColor
                        )
                        Text(
                            text = "Used",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                // Stat Columns
                Column(modifier = Modifier.weight(1f)) {
                    StatRow(
                        label = "Total Spent",
                        value = "$currencySymbol${String.format(Locale.US, "%.2f", totalMonthlyExpense)}",
                        color = if (isOverBudget) TargetExceeded else MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    StatRow(
                        label = if (isOverBudget) "Over Budget" else "Remaining Budget",
                        value = if (isOverBudget) {
                            "+$currencySymbol${String.format(Locale.US, "%.2f", totalMonthlyExpense - monthlyBudget)}"
                        } else {
                            "$currencySymbol${String.format(Locale.US, "%.2f", remaining)}"
                        },
                        color = if (isOverBudget) TargetExceeded else IncomeGreen
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    StatRow(
                        label = "Projected End-of-Month",
                        value = "$currencySymbol${String.format(Locale.US, "%.2f", projectedMonthEnd)}",
                        color = if (projectedMonthEnd > monthlyBudget) TargetWarning else MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
private fun StatRow(label: String, value: String, color: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}

@Composable
fun CategoryDonutChartCard(
    categoryTotals: Map<String, Double>,
    currencySymbol: String,
    modifier: Modifier = Modifier
) {
    val totalExpense = categoryTotals.values.sum().coerceAtLeast(0.0)

    val colors = listOf(
        Color(0xFF006C4C),
        Color(0xFF0284C7),
        Color(0xFFF59E0B),
        Color(0xFF8B5CF6),
        Color(0xFFE11D48),
        Color(0xFF10B981),
        Color(0xFF6366F1),
        Color(0xFFEC4899),
        Color(0xFF14B8A6),
        Color(0xFFF97316)
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("category_chart_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Text(
                text = "Expense Breakdown by Category",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Total Monthly Spending: $currencySymbol${String.format(Locale.US, "%.2f", totalExpense)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(18.dp))

            if (categoryTotals.isEmpty() || totalExpense == 0.0) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No expenses recorded this month yet.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp
                    )
                }
            } else {
                // Donut and Legend Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Donut Canvas
                    Box(
                        modifier = Modifier.size(120.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.size(110.dp)) {
                            val stroke = 18.dp.toPx()
                            var currentAngle = -90f

                            val sortedCategories = categoryTotals.entries.sortedByDescending { it.value }
                            sortedCategories.forEachIndexed { index, entry ->
                                val sweep = ((entry.value / totalExpense) * 360f).toFloat()
                                val sliceColor = colors[index % colors.size]

                                drawArc(
                                    color = sliceColor,
                                    startAngle = currentAngle,
                                    sweepAngle = (sweep - 2f).coerceAtLeast(1f),
                                    useCenter = false,
                                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                                )
                                currentAngle += sweep
                            }
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${categoryTotals.size}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Categories",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(18.dp))

                    // Legend list
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val sorted = categoryTotals.entries.sortedByDescending { it.value }.take(5)
                        sorted.forEachIndexed { index, entry ->
                            val color = colors[index % colors.size]
                            val percent = (entry.value / totalExpense) * 100

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(color)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = entry.key,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 1,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                Text(
                                    text = "${String.format(Locale.US, "%.0f", percent)}% ($currencySymbol${String.format(Locale.US, "%.0f", entry.value)})",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
