package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.TargetExceeded
import com.example.ui.theme.TargetWarning
import com.example.ui.theme.TransferBlue
import com.example.util.DateUtils
import java.util.Calendar
import java.util.Locale

@Composable
fun CalendarView(
    year: Int,
    month: Int,
    selectedDateIso: String,
    dailyExpenses: Map<Int, Double>,
    dailyTarget: Double,
    currencySymbol: String,
    onDateSelected: (String) -> Unit,
    onPrevMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onJumpToToday: () -> Unit,
    modifier: Modifier = Modifier
) {
    val daysInMonth = DateUtils.getDaysInMonth(year, month)
    val firstDayOfWeek = DateUtils.getFirstDayOfWeekInMonth(year, month) // 1..7 (1=Sun)
    val offset = firstDayOfWeek - 1 // 0..6

    val todayCal = Calendar.getInstance()
    val isCurrentYearMonth = (todayCal.get(Calendar.YEAR) == year && (todayCal.get(Calendar.MONTH) + 1) == month)
    val todayDay = if (isCurrentYearMonth) todayCal.get(Calendar.DAY_OF_MONTH) else -1

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("calendar_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header: Month, Year, and Navigation Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = DateUtils.formatToDisplayMonth(year, month),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Daily Target: $currencySymbol${String.format(Locale.US, "%.0f", dailyTarget)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onPrevMonth,
                        modifier = Modifier.testTag("prev_month_btn")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                            contentDescription = "Previous Month"
                        )
                    }

                    FilledTonalButton(
                        onClick = onJumpToToday,
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("today_btn"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            Icons.Default.Today,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Today", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    IconButton(
                        onClick = onNextMonth,
                        modifier = Modifier.testTag("next_month_btn")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Next Month"
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Weekdays Header
            val weekdays = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                for (day in weekdays) {
                    Text(
                        text = day,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = if (day == "Sun" || day == "Sat") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Days Grid
            val totalCells = offset + daysInMonth
            val rows = (totalCells + 6) / 7

            for (r in 0 until rows) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    for (c in 0 until 7) {
                        val cellIndex = r * 7 + c
                        val dayNumber = cellIndex - offset + 1

                        if (dayNumber in 1..daysInMonth) {
                            val currentCellIso = DateUtils.toIsoDate(year, month, dayNumber)
                            val isSelected = currentCellIso == selectedDateIso
                            val isToday = dayNumber == todayDay
                            val spent = dailyExpenses[dayNumber] ?: 0.0

                            CalendarDayCell(
                                dayNumber = dayNumber,
                                spentAmount = spent,
                                dailyTarget = dailyTarget,
                                currencySymbol = currencySymbol,
                                isSelected = isSelected,
                                isToday = isToday,
                                onClick = { onDateSelected(currentCellIso) },
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(vertical = 3.dp, horizontal = 2.dp)
                            )
                        } else {
                            // Empty cell
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Legend indicators
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LegendItem(color = IncomeGreen, label = "Under Target")
                Spacer(modifier = Modifier.width(16.dp))
                LegendItem(color = TargetWarning, label = "Near Target")
                Spacer(modifier = Modifier.width(16.dp))
                LegendItem(color = TargetExceeded, label = "Over Target")
            }
        }
    }
}

@Composable
private fun CalendarDayCell(
    dayNumber: Int,
    spentAmount: Double,
    dailyTarget: Double,
    currencySymbol: String,
    isSelected: Boolean,
    isToday: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val hasExpense = spentAmount > 0.0
    val isOverTarget = hasExpense && dailyTarget > 0 && spentAmount > dailyTarget
    val isNearTarget = hasExpense && dailyTarget > 0 && spentAmount >= dailyTarget * 0.8 && spentAmount <= dailyTarget

    val statusDotColor = when {
        !hasExpense -> Color.Transparent
        isOverTarget -> TargetExceeded
        isNearTarget -> TargetWarning
        else -> IncomeGreen
    }

    Surface(
        onClick = onClick,
        modifier = modifier
            .aspectRatio(0.85f)
            .clip(RoundedCornerShape(12.dp))
            .then(
                if (isToday && !isSelected) {
                    Modifier.border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp))
                } else Modifier
            )
            .testTag("calendar_day_$dayNumber"),
        shape = RoundedCornerShape(12.dp),
        color = when {
            isSelected -> MaterialTheme.colorScheme.primary
            hasExpense && isOverTarget -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f)
            hasExpense -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            else -> Color.Transparent
        },
        tonalElevation = if (isSelected) 4.dp else 0.dp
    ) {
        Column(
            modifier = Modifier
                .padding(2.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = dayNumber.toString(),
                fontSize = 13.sp,
                fontWeight = if (isSelected || isToday) FontWeight.Bold else FontWeight.Medium,
                color = when {
                    isSelected -> MaterialTheme.colorScheme.onPrimary
                    isToday -> MaterialTheme.colorScheme.primary
                    else -> MaterialTheme.colorScheme.onSurface
                }
            )

            if (hasExpense) {
                Text(
                    text = "$currencySymbol${if (spentAmount >= 1000) String.format(Locale.US, "%.0fk", spentAmount / 1000) else String.format(Locale.US, "%.0f", spentAmount)}",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = when {
                        isSelected -> MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.9f)
                        isOverTarget -> TargetExceeded
                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    maxLines = 1
                )
            } else {
                Spacer(modifier = Modifier.height(11.dp))
            }

            // Dot Indicator
            Box(
                modifier = Modifier
                    .size(5.dp)
                    .clip(CircleShape)
                    .background(
                        if (isSelected && hasExpense) MaterialTheme.colorScheme.onPrimary else statusDotColor
                    )
            )
        }
    }
}

@Composable
private fun LegendItem(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
