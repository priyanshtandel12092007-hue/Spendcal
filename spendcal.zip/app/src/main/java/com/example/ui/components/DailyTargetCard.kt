package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.IncomeGreenLight
import com.example.ui.theme.TargetExceeded
import com.example.ui.theme.TargetWarning
import com.example.util.DateUtils
import java.util.Locale

@Composable
fun DailyTargetCard(
    dateIso: String,
    dailySpent: Double,
    dailyTarget: Double,
    currencySymbol: String,
    onEditTarget: () -> Unit,
    modifier: Modifier = Modifier
) {
    val progress = if (dailyTarget > 0) (dailySpent / dailyTarget).toFloat().coerceIn(0f, 1.5f) else 0f
    val displayProgress = progress.coerceAtMost(1f)
    val animatedProgress by animateFloatAsState(targetValue = displayProgress, label = "target_progress")

    val isOverTarget = dailyTarget > 0 && dailySpent > dailyTarget
    val isNearTarget = dailyTarget > 0 && dailySpent >= dailyTarget * 0.8 && dailySpent <= dailyTarget
    val remaining = (dailyTarget - dailySpent).coerceAtLeast(0.0)
    val overAmount = (dailySpent - dailyTarget).coerceAtLeast(0.0)

    val progressColor by animateColorAsState(
        targetValue = when {
            isOverTarget -> TargetExceeded
            isNearTarget -> TargetWarning
            else -> IncomeGreen
        },
        label = "target_color"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("daily_target_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = DateUtils.formatIsoToDisplay(dateIso),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Daily Target Status",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = when {
                        isOverTarget -> TargetExceeded.copy(alpha = 0.15f)
                        isNearTarget -> TargetWarning.copy(alpha = 0.15f)
                        else -> IncomeGreen.copy(alpha = 0.15f)
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isOverTarget) Icons.Default.Warning else Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = progressColor,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = when {
                                isOverTarget -> "Exceeded"
                                isNearTarget -> "Near Limit"
                                else -> "On Track"
                            },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = progressColor
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Spending and Target Numbers
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text(
                        text = "Spent Today",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "$currencySymbol${String.format(Locale.US, "%.2f", dailySpent)}",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isOverTarget) TargetExceeded else MaterialTheme.colorScheme.onSurface
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Daily Target: $currencySymbol${String.format(Locale.US, "%.2f", dailyTarget)}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        IconButton(
                            onClick = onEditTarget,
                            modifier = Modifier
                                .size(28.dp)
                                .testTag("edit_daily_target_button")
                        ) {
                            Icon(
                                Icons.Default.Edit,
                                contentDescription = "Edit Target",
                                modifier = Modifier.size(14.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Text(
                        text = if (isOverTarget) {
                            "+$currencySymbol${String.format(Locale.US, "%.2f", overAmount)} over target"
                        } else {
                            "$currencySymbol${String.format(Locale.US, "%.2f", remaining)} left to spend"
                        },
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isOverTarget) TargetExceeded else IncomeGreen
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Animated Progress Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(animatedProgress)
                        .height(8.dp)
                        .clip(CircleShape)
                        .background(progressColor)
                )
            }
        }
    }
}
