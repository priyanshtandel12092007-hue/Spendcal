package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.AccountEntity
import com.example.data.model.BudgetSettingEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.data.repository.ExpenseRepository
import com.example.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

data class MonthSummary(
    val year: Int,
    val month: Int,
    val totalExpense: Double,
    val totalIncome: Double,
    val totalTransfers: Double,
    val dailyAverage: Double,
    val projectedMonthEnd: Double,
    val daysOverTarget: Int,
    val categoryTotals: Map<String, Double>,
    val dailyTotals: Map<Int, Double>
)

data class AccountBalance(
    val account: AccountEntity,
    val currentBalance: Double
)

class ExpenseViewModel(
    private val repository: ExpenseRepository
) : ViewModel() {

    init {
        viewModelScope.launch {
            repository.initializeDefaultDataIfEmpty()
        }
    }

    private val cal = Calendar.getInstance()
    private val _currentYear = MutableStateFlow(cal.get(Calendar.YEAR))
    val currentYear: StateFlow<Int> = _currentYear.asStateFlow()

    private val _currentMonth = MutableStateFlow(cal.get(Calendar.MONTH) + 1)
    val currentMonth: StateFlow<Int> = _currentMonth.asStateFlow()

    private val _selectedDate = MutableStateFlow(DateUtils.getTodayIso())
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    val allTransactions: StateFlow<List<TransactionEntity>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAccounts: StateFlow<List<AccountEntity>> = repository.allAccounts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val budgetSettings: StateFlow<BudgetSettingEntity> = repository.budgetSettings
        .combine(MutableStateFlow(BudgetSettingEntity())) { setting, default ->
            setting ?: default
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BudgetSettingEntity())

    // Month summary calculations reactively updated
    val monthSummary: StateFlow<MonthSummary> = combine(
        allTransactions,
        _currentYear,
        _currentMonth,
        budgetSettings
    ) { txList, year, month, settings ->
        val monthPrefix = String.format("%04d-%02d", year, month)
        val monthTransactions = txList.filter { it.date.startsWith(monthPrefix) }

        var totalExpense = 0.0
        var totalIncome = 0.0
        var totalTransfers = 0.0
        val categoryTotals = mutableMapOf<String, Double>()
        val dailyTotals = mutableMapOf<Int, Double>()

        for (tx in monthTransactions) {
            when (tx.type) {
                TransactionType.EXPENSE.name -> {
                    totalExpense += tx.amount
                    categoryTotals[tx.category] = (categoryTotals[tx.category] ?: 0.0) + tx.amount

                    val day = tx.date.split("-").getOrNull(2)?.toIntOrNull() ?: 1
                    dailyTotals[day] = (dailyTotals[day] ?: 0.0) + tx.amount
                }
                TransactionType.INCOME.name -> {
                    totalIncome += tx.amount
                }
                TransactionType.TRANSFER.name -> {
                    totalTransfers += tx.amount
                    if (tx.transferFee > 0) {
                        totalExpense += tx.transferFee
                    }
                }
            }
        }

        val daysInMonth = DateUtils.getDaysInMonth(year, month)
        val todayCal = Calendar.getInstance()
        val isCurrentActualMonth = (todayCal.get(Calendar.YEAR) == year && (todayCal.get(Calendar.MONTH) + 1) == month)
        val daysElapsed = if (isCurrentActualMonth) {
            todayCal.get(Calendar.DAY_OF_MONTH).coerceAtLeast(1)
        } else {
            daysInMonth
        }

        val dailyAvg = if (daysElapsed > 0) totalExpense / daysElapsed else 0.0
        val projected = dailyAvg * daysInMonth
        val daysOver = dailyTotals.count { (_, spent) -> spent > settings.dailyTarget }

        MonthSummary(
            year = year,
            month = month,
            totalExpense = totalExpense,
            totalIncome = totalIncome,
            totalTransfers = totalTransfers,
            dailyAverage = dailyAvg,
            projectedMonthEnd = projected,
            daysOverTarget = daysOver,
            categoryTotals = categoryTotals,
            dailyTotals = dailyTotals
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        MonthSummary(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, 0.0, 0.0, 0.0, 0.0, 0.0, 0, emptyMap(), emptyMap())
    )

    // Account Balances
    val accountBalances: StateFlow<List<AccountBalance>> = combine(
        allAccounts,
        allTransactions
    ) { accounts, txList ->
        accounts.map { account ->
            var balance = account.initialBalance
            for (tx in txList) {
                if (tx.accountId == account.id) {
                    when (tx.type) {
                        TransactionType.EXPENSE.name -> balance -= tx.amount
                        TransactionType.INCOME.name -> balance += tx.amount
                        TransactionType.TRANSFER.name -> balance -= (tx.amount + tx.transferFee)
                    }
                }
                if (tx.type == TransactionType.TRANSFER.name && tx.toAccountId == account.id) {
                    balance += tx.amount
                }
            }
            AccountBalance(account, balance)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected Date transactions & daily spent
    val selectedDayTransactions: StateFlow<List<TransactionEntity>> = combine(
        allTransactions,
        _selectedDate
    ) { txList, date ->
        txList.filter { it.date == date }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedDayExpense: StateFlow<Double> = selectedDayTransactions.combine(_selectedDate) { txList, _ ->
        txList.filter { it.type == TransactionType.EXPENSE.name }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Dialog state
    var editingTransaction = MutableStateFlow<TransactionEntity?>(null)
        private set

    var showAddDialog = MutableStateFlow(false)
        private set

    var showTransferDialog = MutableStateFlow(false)
        private set

    var showCalculatorDialog = MutableStateFlow(false)
        private set

    fun openAddTransaction(transactionToEdit: TransactionEntity? = null) {
        editingTransaction.value = transactionToEdit
        showAddDialog.value = true
    }

    fun closeAddTransaction() {
        editingTransaction.value = null
        showAddDialog.value = false
    }

    fun openTransferDialog() {
        showTransferDialog.value = true
    }

    fun closeTransferDialog() {
        showTransferDialog.value = false
    }

    fun openCalculator() {
        showCalculatorDialog.value = true
    }

    fun closeCalculator() {
        showCalculatorDialog.value = false
    }

    fun selectDate(dateIso: String) {
        _selectedDate.value = dateIso
        val parts = DateUtils.parseIsoParts(dateIso)
        _currentYear.value = parts.first
        _currentMonth.value = parts.second
    }

    fun nextMonth() {
        if (_currentMonth.value == 12) {
            _currentMonth.value = 1
            _currentYear.value += 1
        } else {
            _currentMonth.value += 1
        }
    }

    fun prevMonth() {
        if (_currentMonth.value == 1) {
            _currentMonth.value = 12
            _currentYear.value -= 1
        } else {
            _currentMonth.value -= 1
        }
    }

    fun jumpToToday() {
        val today = Calendar.getInstance()
        _currentYear.value = today.get(Calendar.YEAR)
        _currentMonth.value = today.get(Calendar.MONTH) + 1
        _selectedDate.value = DateUtils.getTodayIso()
    }

    fun saveTransaction(
        id: Long = 0,
        type: String,
        amount: Double,
        title: String,
        category: String,
        date: String,
        accountId: Long,
        toAccountId: Long? = null,
        note: String = "",
        transferFee: Double = 0.0
    ) {
        viewModelScope.launch {
            val entity = TransactionEntity(
                id = id,
                type = type,
                amount = amount,
                title = title.ifBlank { category },
                category = category,
                date = date,
                accountId = accountId,
                toAccountId = toAccountId,
                note = note,
                transferFee = transferFee
            )
            repository.insertTransaction(entity)
            closeAddTransaction()
            closeTransferDialog()
        }
    }

    fun recordTransfer(
        fromAccountId: Long,
        toAccountId: Long,
        amount: Double,
        title: String,
        date: String,
        fee: Double = 0.0,
        note: String = ""
    ) {
        viewModelScope.launch {
            val transferTx = TransactionEntity(
                type = TransactionType.TRANSFER.name,
                amount = amount,
                title = title.ifBlank { "Transfer to Account" },
                category = "Transfer",
                date = date,
                accountId = fromAccountId,
                toAccountId = toAccountId,
                note = note,
                transferFee = fee
            )
            repository.insertTransaction(transferTx)
            closeTransferDialog()
        }
    }

    fun deleteTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            repository.deleteTransaction(transaction)
        }
    }

    fun updateBudgetSettings(
        dailyTarget: Double,
        monthlyBudget: Double,
        currencySymbol: String,
        currencyName: String
    ) {
        viewModelScope.launch {
            repository.saveBudgetSettings(
                BudgetSettingEntity(
                    id = 1,
                    dailyTarget = dailyTarget,
                    monthlyBudget = monthlyBudget,
                    currencySymbol = currencySymbol,
                    currencyName = currencyName
                )
            )
        }
    }

    fun addAccount(name: String, type: String, initialBalance: Double, colorHex: String) {
        viewModelScope.launch {
            repository.insertAccount(
                AccountEntity(
                    name = name,
                    type = type,
                    initialBalance = initialBalance,
                    colorHex = colorHex
                )
            )
        }
    }

    fun deleteAccount(account: AccountEntity) {
        viewModelScope.launch {
            repository.deleteAccount(account)
        }
    }

    fun resetDemoData() {
        viewModelScope.launch {
            repository.clearAndResetDemoData()
            jumpToToday()
        }
    }
}

class ExpenseViewModelFactory(
    private val repository: ExpenseRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ExpenseViewModel::class.java)) {
            return ExpenseViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
