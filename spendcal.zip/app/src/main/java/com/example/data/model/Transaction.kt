package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TransactionType {
    EXPENSE,
    INCOME,
    TRANSFER
}

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: String, // "EXPENSE", "INCOME", "TRANSFER"
    val amount: Double,
    val title: String,
    val category: String, // e.g. "Food", "Transport", "Bills", etc.
    val date: String, // "YYYY-MM-DD" e.g. "2026-10-29"
    val timestamp: Long = System.currentTimeMillis(),
    val accountId: Long, // Source account ID
    val toAccountId: Long? = null, // Destination account ID for TRANSFER
    val note: String = "",
    val transferFee: Double = 0.0
)

object Categories {
    val expenseCategories = listOf(
        "Food & Dining",
        "Groceries",
        "Transport & Fuel",
        "Shopping & Clothes",
        "Bills & Utilities",
        "Entertainment",
        "Health & Medical",
        "Education",
        "Travel",
        "Home & Rent",
        "Personal Care",
        "General / Other"
    )

    val incomeCategories = listOf(
        "Salary",
        "Freelance",
        "Investments",
        "Business",
        "Gift / Reward",
        "Other Income"
    )

    val transferCategory = "Transfer"
}
