package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "budget_settings")
data class BudgetSettingEntity(
    @PrimaryKey
    val id: Int = 1,
    val dailyTarget: Double = 50.0,
    val monthlyBudget: Double = 1500.0,
    val currencySymbol: String = "$",
    val currencyName: String = "USD ($)"
)
