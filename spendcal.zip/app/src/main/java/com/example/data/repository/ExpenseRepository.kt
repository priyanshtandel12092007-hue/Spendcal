package com.example.data.repository

import com.example.data.local.AccountDao
import com.example.data.local.BudgetDao
import com.example.data.local.TransactionDao
import com.example.data.model.AccountEntity
import com.example.data.model.BudgetSettingEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.util.DateUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.Calendar

class ExpenseRepository(
    private val transactionDao: TransactionDao,
    private val accountDao: AccountDao,
    private val budgetDao: BudgetDao
) {
    val allTransactions: Flow<List<TransactionEntity>> = transactionDao.getAllTransactions()
    val allAccounts: Flow<List<AccountEntity>> = accountDao.getAllAccounts()
    val budgetSettings: Flow<BudgetSettingEntity?> = budgetDao.getBudgetSettings()

    fun getTransactionsForDate(date: String): Flow<List<TransactionEntity>> {
        return transactionDao.getTransactionsForDate(date)
    }

    fun getTransactionsForMonth(yearMonthPrefix: String): Flow<List<TransactionEntity>> {
        return transactionDao.getTransactionsForMonth(yearMonthPrefix)
    }

    suspend fun insertTransaction(transaction: TransactionEntity): Long = withContext(Dispatchers.IO) {
        transactionDao.insertTransaction(transaction)
    }

    suspend fun updateTransaction(transaction: TransactionEntity) = withContext(Dispatchers.IO) {
        transactionDao.updateTransaction(transaction)
    }

    suspend fun deleteTransaction(transaction: TransactionEntity) = withContext(Dispatchers.IO) {
        transactionDao.deleteTransaction(transaction)
    }

    suspend fun deleteTransactionById(id: Long) = withContext(Dispatchers.IO) {
        transactionDao.deleteTransactionById(id)
    }

    suspend fun insertAccount(account: AccountEntity): Long = withContext(Dispatchers.IO) {
        accountDao.insertAccount(account)
    }

    suspend fun updateAccount(account: AccountEntity) = withContext(Dispatchers.IO) {
        accountDao.updateAccount(account)
    }

    suspend fun deleteAccount(account: AccountEntity) = withContext(Dispatchers.IO) {
        accountDao.deleteAccount(account)
    }

    suspend fun saveBudgetSettings(settings: BudgetSettingEntity) = withContext(Dispatchers.IO) {
        budgetDao.setBudgetSettings(settings)
    }

    suspend fun initializeDefaultDataIfEmpty() = withContext(Dispatchers.IO) {
        if (accountDao.getCount() == 0) {
            // Seed default accounts
            val bankId = accountDao.insertAccount(
                AccountEntity(name = "Main Bank Checking", type = "BANK", initialBalance = 3200.0, colorHex = "#0284C7", isDefault = true)
            )
            val cashId = accountDao.insertAccount(
                AccountEntity(name = "Cash Wallet", type = "CASH", initialBalance = 240.0, colorHex = "#10B981")
            )
            val savingsId = accountDao.insertAccount(
                AccountEntity(name = "Savings Vault", type = "SAVINGS", initialBalance = 6500.0, colorHex = "#8B5CF6")
            )
            val creditCardId = accountDao.insertAccount(
                AccountEntity(name = "Credit Card", type = "CREDIT_CARD", initialBalance = 0.0, colorHex = "#F59E0B")
            )

            // Seed default settings
            budgetDao.setBudgetSettings(
                BudgetSettingEntity(
                    id = 1,
                    dailyTarget = 50.0,
                    monthlyBudget = 1500.0,
                    currencySymbol = "$",
                    currencyName = "USD ($)"
                )
            )

            // Seed sample transactions for current month
            val cal = Calendar.getInstance()
            val year = cal.get(Calendar.YEAR)
            val month = cal.get(Calendar.MONTH) + 1
            val todayDay = cal.get(Calendar.DAY_OF_MONTH)

            // Today's transactions
            val todayStr = DateUtils.toIsoDate(year, month, todayDay)
            transactionDao.insertTransaction(
                TransactionEntity(
                    type = TransactionType.EXPENSE.name,
                    amount = 14.50,
                    title = "Lunch & Coffee",
                    category = "Food & Dining",
                    date = todayStr,
                    accountId = bankId,
                    note = "Cafe with colleagues"
                )
            )
            transactionDao.insertTransaction(
                TransactionEntity(
                    type = TransactionType.EXPENSE.name,
                    amount = 22.00,
                    title = "Grocery essentials",
                    category = "Groceries",
                    date = todayStr,
                    accountId = cashId,
                    note = "Fruits and snacks"
                )
            )

            // Yesterday
            if (todayDay > 1) {
                val yDayStr = DateUtils.toIsoDate(year, month, todayDay - 1)
                transactionDao.insertTransaction(
                    TransactionEntity(
                        type = TransactionType.EXPENSE.name,
                        amount = 45.00,
                        title = "Fuel refill",
                        category = "Transport & Fuel",
                        date = yDayStr,
                        accountId = bankId
                    )
                )
                // A transfer yesterday
                transactionDao.insertTransaction(
                    TransactionEntity(
                        type = TransactionType.TRANSFER.name,
                        amount = 100.00,
                        title = "ATM Cash Withdrawal",
                        category = "Transfer",
                        date = yDayStr,
                        accountId = bankId,
                        toAccountId = cashId,
                        note = "Pocket cash",
                        transferFee = 0.0
                    )
                )
            }

            // Earlier days in month
            if (todayDay > 4) {
                val day4Str = DateUtils.toIsoDate(year, month, todayDay - 4)
                transactionDao.insertTransaction(
                    TransactionEntity(
                        type = TransactionType.EXPENSE.name,
                        amount = 68.50, // Exceeded daily target day
                        title = "Weekend Dinner & Drinks",
                        category = "Food & Dining",
                        date = day4Str,
                        accountId = creditCardId
                    )
                )
            }

            if (todayDay > 7) {
                val day7Str = DateUtils.toIsoDate(year, month, todayDay - 7)
                transactionDao.insertTransaction(
                    TransactionEntity(
                        type = TransactionType.EXPENSE.name,
                        amount = 32.00,
                        title = "Pharmacy & Vitamins",
                        category = "Health & Medical",
                        date = day7Str,
                        accountId = bankId
                    )
                )
            }

            // Salary on day 1
            val day1Str = DateUtils.toIsoDate(year, month, 1)
            transactionDao.insertTransaction(
                TransactionEntity(
                    type = TransactionType.INCOME.name,
                    amount = 2800.00,
                    title = "Monthly Salary Deposit",
                    category = "Salary",
                    date = day1Str,
                    accountId = bankId
                )
            )

            // Transfer to savings vault
            transactionDao.insertTransaction(
                TransactionEntity(
                    type = TransactionType.TRANSFER.name,
                    amount = 500.00,
                    title = "Monthly Savings Allocation",
                    category = "Transfer",
                    date = day1Str,
                    accountId = bankId,
                    toAccountId = savingsId,
                    note = "Emergency fund allocation"
                )
            )
        }
    }

    suspend fun clearAndResetDemoData() = withContext(Dispatchers.IO) {
        transactionDao.clearAll()
        accountDao.clearAll()
        initializeDefaultDataIfEmpty()
    }
}
