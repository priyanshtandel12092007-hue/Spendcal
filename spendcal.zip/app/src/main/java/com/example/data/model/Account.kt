package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class AccountType {
    CASH,
    BANK,
    CREDIT_CARD,
    SAVINGS,
    DIGITAL_WALLET
}

@Entity(tableName = "accounts")
data class AccountEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val type: String, // "CASH", "BANK", "CREDIT_CARD", "SAVINGS", "DIGITAL_WALLET"
    val initialBalance: Double = 0.0,
    val colorHex: String = "#006C4C",
    val isDefault: Boolean = false
)
