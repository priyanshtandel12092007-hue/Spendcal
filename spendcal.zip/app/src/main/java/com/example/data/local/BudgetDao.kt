package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.BudgetSettingEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BudgetDao {
    @Query("SELECT * FROM budget_settings WHERE id = 1")
    fun getBudgetSettings(): Flow<BudgetSettingEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setBudgetSettings(settings: BudgetSettingEntity)

    @Update
    suspend fun updateBudgetSettings(settings: BudgetSettingEntity)
}
