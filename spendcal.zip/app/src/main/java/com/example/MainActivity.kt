package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.PieChart
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.AppDatabase
import com.example.data.repository.ExpenseRepository
import com.example.ui.components.AddAccountDialog
import com.example.ui.components.AddEditTransactionSheet
import com.example.ui.components.BuiltInCalculatorSheet
import com.example.ui.components.EditDailyTargetDialog
import com.example.ui.components.EditMonthlyBudgetDialog
import com.example.ui.components.TransferSheet
import com.example.ui.screens.BudgetsChartsScreen
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TransfersAccountsScreen
import com.example.ui.theme.SpendCalTheme
import com.example.ui.viewmodel.ExpenseViewModel
import com.example.ui.viewmodel.ExpenseViewModelFactory

enum class AppTab(val title: String, val selectedIcon: ImageVector, val unselectedIcon: ImageVector) {
    CALENDAR("Calendar", Icons.Filled.CalendarMonth, Icons.Outlined.CalendarMonth),
    BUDGETS("Charts", Icons.Filled.PieChart, Icons.Outlined.PieChart),
    TRANSFERS("Transfers", Icons.Filled.SwapHoriz, Icons.Outlined.SwapHoriz),
    SETTINGS("Settings", Icons.Filled.Settings, Icons.Outlined.Settings)
}

class MainActivity : ComponentActivity() {

    private val viewModel: ExpenseViewModel by viewModels {
        val database = AppDatabase.getDatabase(applicationContext)
        val repository = ExpenseRepository(
            transactionDao = database.transactionDao(),
            accountDao = database.accountDao(),
            budgetDao = database.budgetDao()
        )
        ExpenseViewModelFactory(repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            SpendCalTheme {
                SpendCalApp(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpendCalApp(viewModel: ExpenseViewModel) {
    var selectedTab by remember { mutableStateOf(AppTab.CALENDAR) }

    // Dialog state
    val showAddTx by viewModel.showAddDialog.collectAsStateWithLifecycle()
    val showTransfer by viewModel.showTransferDialog.collectAsStateWithLifecycle()
    val showCalculator by viewModel.showCalculatorDialog.collectAsStateWithLifecycle()
    val editingTx by viewModel.editingTransaction.collectAsStateWithLifecycle()

    val accounts by viewModel.allAccounts.collectAsStateWithLifecycle()
    val budgetSettings by viewModel.budgetSettings.collectAsStateWithLifecycle()
    val selectedDate by viewModel.selectedDate.collectAsStateWithLifecycle()

    var showDailyTargetDialog by remember { mutableStateOf(false) }
    var showMonthlyBudgetDialog by remember { mutableStateOf(false) }
    var showAddAccountDialog by remember { mutableStateOf(false) }

    // Handle Back Press to return to Calendar tab
    BackHandler(enabled = selectedTab != AppTab.CALENDAR) {
        selectedTab = AppTab.CALENDAR
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(30.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.CalendarMonth,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SpendCal",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 20.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                actions = {
                    // Quick Calculator Button available in TopBar across all tabs
                    IconButton(
                        onClick = { viewModel.openCalculator() },
                        modifier = Modifier.testTag("topbar_calculator_button")
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.Calculate,
                                    contentDescription = "Quick Calculator",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                AppTab.values().forEach { tab ->
                    val isSelected = selectedTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        icon = {
                            Icon(
                                imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                contentDescription = tab.title
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        modifier = Modifier.testTag("nav_item_${tab.name.lowercase()}")
                    )
                }
            }
        },
        floatingActionButton = {
            if (selectedTab == AppTab.CALENDAR) {
                FloatingActionButton(
                    onClick = { viewModel.openAddTransaction() },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.testTag("main_add_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Transaction", modifier = Modifier.size(26.dp))
                }
            } else if (selectedTab == AppTab.TRANSFERS) {
                ExtendedFloatingActionButton(
                    onClick = { viewModel.openTransferDialog() },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    shape = RoundedCornerShape(16.dp),
                    icon = { Icon(Icons.Default.SwapHoriz, contentDescription = null) },
                    text = { Text("Transfer Money", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("transfers_fab")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(targetState = selectedTab, label = "tab_fade") { tab ->
                when (tab) {
                    AppTab.CALENDAR -> CalendarScreen(
                        viewModel = viewModel,
                        onOpenDailyTargetDialog = { showDailyTargetDialog = true }
                    )
                    AppTab.BUDGETS -> BudgetsChartsScreen(
                        viewModel = viewModel,
                        onOpenBudgetDialog = { showMonthlyBudgetDialog = true }
                    )
                    AppTab.TRANSFERS -> TransfersAccountsScreen(
                        viewModel = viewModel,
                        onOpenAddAccountDialog = { showAddAccountDialog = true }
                    )
                    AppTab.SETTINGS -> SettingsScreen(
                        viewModel = viewModel,
                        onOpenDailyTargetDialog = { showDailyTargetDialog = true },
                        onOpenMonthlyBudgetDialog = { showMonthlyBudgetDialog = true }
                    )
                }
            }
        }

        // Modals & Sheets
        if (showAddTx) {
            AddEditTransactionSheet(
                onDismiss = { viewModel.closeAddTransaction() },
                accounts = accounts,
                currencySymbol = budgetSettings.currencySymbol,
                initialDate = selectedDate,
                editingTx = editingTx,
                onSave = { id, type, amount, title, category, date, accountId, toAccountId, note, fee ->
                    viewModel.saveTransaction(
                        id = id,
                        type = type,
                        amount = amount,
                        title = title,
                        category = category,
                        date = date,
                        accountId = accountId,
                        toAccountId = toAccountId,
                        note = note,
                        transferFee = fee
                    )
                }
            )
        }

        if (showTransfer) {
            TransferSheet(
                accounts = accounts,
                currencySymbol = budgetSettings.currencySymbol,
                initialDate = selectedDate,
                onDismiss = { viewModel.closeTransferDialog() },
                onTransfer = { fromId, toId, amt, title, date, fee, note ->
                    viewModel.recordTransfer(
                        fromAccountId = fromId,
                        toAccountId = toId,
                        amount = amt,
                        title = title,
                        date = date,
                        fee = fee,
                        note = note
                    )
                }
            )
        }

        if (showCalculator) {
            BuiltInCalculatorSheet(
                onDismiss = { viewModel.closeCalculator() }
            )
        }

        if (showDailyTargetDialog) {
            EditDailyTargetDialog(
                currentTarget = budgetSettings.dailyTarget,
                currencySymbol = budgetSettings.currencySymbol,
                onDismiss = { showDailyTargetDialog = false },
                onSave = { newTarget ->
                    viewModel.updateBudgetSettings(
                        dailyTarget = newTarget,
                        monthlyBudget = budgetSettings.monthlyBudget,
                        currencySymbol = budgetSettings.currencySymbol,
                        currencyName = budgetSettings.currencyName
                    )
                    showDailyTargetDialog = false
                }
            )
        }

        if (showMonthlyBudgetDialog) {
            EditMonthlyBudgetDialog(
                currentBudget = budgetSettings.monthlyBudget,
                currencySymbol = budgetSettings.currencySymbol,
                onDismiss = { showMonthlyBudgetDialog = false },
                onSave = { newBudget ->
                    viewModel.updateBudgetSettings(
                        dailyTarget = budgetSettings.dailyTarget,
                        monthlyBudget = newBudget,
                        currencySymbol = budgetSettings.currencySymbol,
                        currencyName = budgetSettings.currencyName
                    )
                    showMonthlyBudgetDialog = false
                }
            )
        }

        if (showAddAccountDialog) {
            AddAccountDialog(
                currencySymbol = budgetSettings.currencySymbol,
                onDismiss = { showAddAccountDialog = false },
                onSave = { name, type, balance, colorHex ->
                    viewModel.addAccount(name, type, balance, colorHex)
                    showAddAccountDialog = false
                }
            )
        }
    }
}
